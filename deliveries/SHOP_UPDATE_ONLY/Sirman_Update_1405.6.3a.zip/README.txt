SIRMAN update 1405.6.3a
1) Unzip this file.
2) In Sirman: Settings -> Update tab -> Load update file.
3) Choose Sirman_Update_1405.6.3a.sirman-update.json
4) Sidebar version must show 1405.6.3α
This file updates HTML only. Native print needs Sirman.exe from the 1405.6.3a shop kit.
